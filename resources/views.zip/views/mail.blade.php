
Hi {{$data['fname']}},

Your Subscription is expire soon 
Best,
[YOUR SIGNATURE]
